import pandas as pd
import joblib
from BCG_classify_customers import predict  # Import the predict function

# Define file paths (Update these with actual paths)
activity_file = "sample_data/activity_data.csv"
customer_file = "sample_data/customer_data.csv"
complaints_file = "sample_data/complaints.xlsx"

# Define model file paths
models = {
    "logistic": {
        "model": "models/logistic_regression/logistic_regression.pkl",
        "scaler": "models/logistic_regression/logistic_scaler.pkl",
        "features": "models/logistic_regression/feature_names.pkl"
    },
    "lda": {
        "model": "models/lda/lda_model.pkl",
        "scaler": None,  # LDA doesn't use a scaler
        "features": "models/lda/feature_names.pkl"
    },
    "adaboost": {
        "model": "models/adaboost/adaboost_model.pkl",
        "scaler": None,  # AdaBoost doesn't use a scaler
        "features": "models/adaboost/feature_names.pkl"
    }
}

# Run prediction for each model type
for model_type, paths in models.items():
    print(f"\n🔹 Testing Model: {model_type.upper()}")
    
    try:
        predictions = predict(
            activity_file, customer_file, complaints_file,
            model_type, paths["model"], paths["scaler"], paths["features"]
        )
        
        print(f"✅ {model_type.upper()} Model Columns:\n{predictions.columns.tolist()}")
    
    except Exception as e:
        print(f"❌ Error testing {model_type.upper()} Model: {e}")
